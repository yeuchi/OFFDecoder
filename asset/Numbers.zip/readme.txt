Numbers.zip Readme File
This zip file contains 10 OFF files. Each one is a 3D
representation of each of the 10 digits 0 to 9. The
digits are each within the bounding box (0,0,0)-(3,5,1),
facing toward the positive z. These files were created
for use with my RoffView and related OFF-processing 
programs. They may be freely used and distributed. I
ask that you give credit if you use them, that you
keep this file with any distribution, and that you
e-mail me and let me know if you use them in anything
interesting.

Ryan Holmes
Ryan <at> Holmes3d <dot> net
September 12, 2002
